# LocationObserverTest
Location tracking in SwiftUI.

<img src="https://raw.githubusercontent.com/daisuke-t-jp/LocationObserverTest/master/Tracking.gif" width="200px">

<br />

<img src="https://raw.githubusercontent.com/daisuke-t-jp/LocationObserverTest/master/SimulatorSetting.png" width="400px">  

Simulator setting.  
